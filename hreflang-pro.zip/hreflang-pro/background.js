// Hreflang Pro v2 — Background Service Worker
// Handles CORS-free fetching, content script injection, badge updates

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_PAGE') {
    fetchPage(message.url)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (message.type === 'EXTRACT_HREFLANG') {
    extractFromTab(message.tabId)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (message.type === 'FETCH_SITEMAP') {
    fetchSitemap(message.url)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (message.type === 'SET_BADGE') {
    const text = message.count > 0 ? String(message.count) : '';
    const color = message.count > 0 ? '#E53935' : '#43A047';
    chrome.action.setBadgeText({ text, tabId: message.tabId });
    chrome.action.setBadgeBackgroundColor({ color, tabId: message.tabId });
    sendResponse({ ok: true });
    return false;
  }

});

// ===== FETCH PAGE — returns HTML, headers, redirect info =====
async function fetchPage(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  const startTime = Date.now();

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'text/html,application/xhtml+xml',
        'User-Agent': 'Mozilla/5.0 (compatible; HreflangPro/2.0)'
      },
      redirect: 'follow'
    });
    clearTimeout(timeout);
    const responseTime = Date.now() - startTime;

    // Extract Link headers for hreflang-via-HTTP-header detection
    const linkHeader = response.headers.get('Link') || '';

    // Extract Content-Language header
    const contentLanguage = response.headers.get('Content-Language') || '';

    // Parse hreflang from Link headers
    // Format: <url>; rel="alternate"; hreflang="en"
    const headerHreflangTags = [];
    if (linkHeader) {
      const parts = linkHeader.split(',');
      for (const part of parts) {
        const urlMatch = part.match(/<([^>]+)>/);
        const relMatch = part.match(/rel\s*=\s*"alternate"/i);
        const hreflangMatch = part.match(/hreflang\s*=\s*"([^"]+)"/i);
        if (urlMatch && relMatch && hreflangMatch) {
          headerHreflangTags.push({
            hreflang: hreflangMatch[1].toLowerCase(),
            href: urlMatch[1]
          });
        }
      }
    }

    const html = response.status === 200 ? await response.text() : '';

    return {
      ok: true,
      status: response.status,
      requestedUrl: url,
      finalUrl: response.url,
      redirected: response.url !== url,
      headerHreflangTags,
      html,
      responseTime,
      contentLanguage
    };
  } catch (err) {
    clearTimeout(timeout);
    const responseTime = Date.now() - startTime;
    return {
      ok: false,
      status: 0,
      requestedUrl: url,
      error: err.name === 'AbortError' ? 'Timeout (8s)' : err.message,
      responseTime,
      contentLanguage: ''
    };
  }
}

// ===== EXTRACT FROM TAB — gets hreflang, canonical, html lang, noindex, relative URLs =====
async function extractFromTab(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      // Hreflang tags
      const hreflangTags = [];
      const rawHreflangs = []; // keep originals to detect relative URLs
      document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(el => {
        const rawHref = el.getAttribute('href');
        rawHreflangs.push(rawHref || '');
        hreflangTags.push({
          hreflang: el.getAttribute('hreflang'),
          href: el.href // resolved absolute URL
        });
      });

      // Canonical
      const canonical = document.querySelector('link[rel="canonical"]');

      // <html lang="...">
      const htmlLang = document.documentElement.getAttribute('lang') || '';

      // Noindex check
      const robotsMeta = document.querySelector('meta[name="robots"]');
      const robotsContent = robotsMeta ? robotsMeta.getAttribute('content') || '' : '';
      const isNoindex = robotsContent.toLowerCase().includes('noindex');

      // Detect hreflang tags placed outside <head> (invalid HTML)
      const outsideHeadCount = document.body
        ? document.body.querySelectorAll('link[rel="alternate"][hreflang]').length
        : 0;

      return {
        hreflangTags,
        rawHreflangs,
        canonical: canonical ? canonical.href : null,
        pageUrl: window.location.href,
        htmlLang: htmlLang.toLowerCase().trim(),
        isNoindex,
        outsideHeadCount
      };
    }
  });

  return { ok: true, data: results[0].result };
}

// ===== FETCH SITEMAP — looks for hreflang in XML sitemap =====
async function fetchSitemap(pageUrl) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);

  try {
    // Derive sitemap URL from page URL
    const origin = new URL(pageUrl).origin;
    const sitemapUrl = origin + '/sitemap.xml';

    const response = await fetch(sitemapUrl, {
      signal: controller.signal,
      headers: { 'Accept': 'application/xml, text/xml, */*' }
    });
    clearTimeout(timeout);

    if (response.status !== 200) {
      return { ok: true, found: false, reason: `sitemap.xml returned ${response.status}` };
    }

    const xml = await response.text();

    // Check if it's a sitemap index (references other sitemaps)
    const isIndex = xml.includes('<sitemapindex');

    // Parse hreflang entries: <xhtml:link rel="alternate" hreflang="..." href="..." />
    const sitemapHreflang = new Map(); // pageUrl -> [{ hreflang, href }]
    const locRegex = /<url>\s*([\s\S]*?)\s*<\/url>/gi;
    let locMatch;

    while ((locMatch = locRegex.exec(xml)) !== null) {
      const block = locMatch[1];
      const locUrl = block.match(/<loc>\s*(.*?)\s*<\/loc>/i);
      if (!locUrl) continue;

      const pageHref = locUrl[1].trim();
      const xhtmlLinks = [];
      const linkRegex = /<xhtml:link[^>]*>/gi;
      let linkMatch;

      while ((linkMatch = linkRegex.exec(block)) !== null) {
        const tag = linkMatch[0];
        const hreflangVal = tag.match(/hreflang\s*=\s*["']([^"']+)["']/i);
        const hrefVal = tag.match(/href\s*=\s*["']([^"']+)["']/i);
        if (hreflangVal && hrefVal) {
          xhtmlLinks.push({
            hreflang: hreflangVal[1].toLowerCase(),
            href: hrefVal[1]
          });
        }
      }

      if (xhtmlLinks.length > 0) {
        sitemapHreflang.set(pageHref, xhtmlLinks);
      }
    }

    // Convert Map to plain object for message passing
    const result = {};
    for (const [key, val] of sitemapHreflang) {
      result[key] = val;
    }

    return {
      ok: true,
      found: true,
      isIndex,
      sitemapUrl,
      entries: result,
      entryCount: sitemapHreflang.size
    };
  } catch (err) {
    clearTimeout(timeout);
    return {
      ok: true,
      found: false,
      reason: err.name === 'AbortError' ? 'Timeout fetching sitemap' : err.message
    };
  }
}
