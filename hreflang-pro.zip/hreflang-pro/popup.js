// Hreflang Pro v2 — Cluster Analysis Engine & UI Renderer
// ========================================================
// Features: Multi-source detection (HTML, HTTP headers, Sitemap),
// Cluster matrix, Copy-fix, Badge count,
// Typo awareness, Redirect detection, <html lang> check, Noindex check

(async function main() {
  const $ = id => document.getElementById(id);

  // ===== TAB MODE DETECTION =====
  const IS_TAB_MODE = new URLSearchParams(window.location.search).has('tab');
  const POPOUT_STORAGE_KEY = '_hreflangProPopoutData';

  if (IS_TAB_MODE) {
    document.body.classList.add('tab-mode');
  }

  const STATES = {
    loading: $('state-loading'),
    empty: $('state-empty'),
    error: $('state-error'),
    results: $('state-results')
  };

  function showState(state) {
    Object.values(STATES).forEach(el => el.style.display = 'none');
    STATES[state].style.display = '';
    // In tab mode: hide rescan (can't scan from tab) and popout (already expanded)
    $('btn-rescan').style.display = (!IS_TAB_MODE && state === 'results') ? '' : 'none';
    $('btn-popout').style.display = (!IS_TAB_MODE && state === 'results') ? '' : 'none';
  }

  // Stored results for export
  let _exportData = null;
  // ===== BUTTON WIRING =====
  $('btn-rescan').addEventListener('click', () => {
    showState('loading');
    $('loading-detail').textContent = 'Extracting hreflang tags from this page';
    runScan();
  });

  $('btn-popout').addEventListener('click', async () => {
    if (!_exportData) return;
    try {
      const serialized = serializeExportData(_exportData);
      await chrome.storage.local.set({ [POPOUT_STORAGE_KEY]: serialized });
      chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?tab=1') });
    } catch (err) {
      console.error('Failed to pop out:', err);
    }
  });

  $('btn-export-csv').addEventListener('click', () => exportCSV());
  $('btn-export-matrix').addEventListener('click', () => exportMatrixVisual());

  // ===== VALID LANGUAGE / REGION CODES =====
  const VALID_LANGS = new Set([
    'aa','ab','af','ak','am','an','ar','as','av','ay','az','ba','be','bg','bh','bi','bm','bn','bo',
    'br','bs','ca','ce','ch','co','cr','cs','cu','cv','cy','da','de','dv','dz','ee','el','en','eo',
    'es','et','eu','fa','ff','fi','fj','fo','fr','fy','ga','gd','gl','gn','gu','gv','ha','he','hi',
    'ho','hr','ht','hu','hy','hz','ia','id','ie','ig','ii','ik','in','io','is','it','iu','ja','jv',
    'jw','ka','kg','ki','kj','kk','kl','km','kn','ko','kr','ks','ku','kv','kw','ky','la','lb','lg',
    'li','ln','lo','lt','lu','lv','mg','mh','mi','mk','ml','mn','mo','mr','ms','mt','my','na','nb',
    'nd','ne','ng','nl','nn','no','nr','nv','ny','oc','oj','om','or','os','pa','pi','pl','ps','pt',
    'qu','rm','rn','ro','ru','rw','sa','sc','sd','se','sg','sh','si','sk','sl','sm','sn','so','sq',
    'sr','ss','st','su','sv','sw','ta','te','tg','th','ti','tk','tl','tn','to','tr','ts','tt','tw',
    'ty','ug','uk','ur','uz','ve','vi','vo','wa','wo','xh','yi','yo','za','zh','zu',
    'zh-hans','zh-hant','pt-br','pt-pt','en-gb','en-us','en-au','en-ca','en-in','en-nz','en-za',
    'es-mx','es-ar','es-co','es-es','es-cl','es-pe','es-ve','fr-fr','fr-ca','fr-be','fr-ch',
    'de-de','de-at','de-ch','nl-nl','nl-be','it-it','it-ch','ru-ru','ja-jp','ko-kr','ar-sa',
    'sv-se','da-dk','fi-fi','nb-no','nn-no','pl-pl','cs-cz','hu-hu','ro-ro','bg-bg','hr-hr',
    'sk-sk','sl-si','sr-rs','uk-ua','el-gr','tr-tr','he-il','th-th','vi-vn','id-id','ms-my',
    'tl-ph','hi-in','bn-bd','ta-in','te-in','ml-in','ur-pk','sw-ke','am-et','zu-za'
  ]);

  const VALID_REGIONS = new Set([
    'AD','AE','AF','AG','AI','AL','AM','AO','AQ','AR','AS','AT','AU','AW','AX','AZ',
    'BA','BB','BD','BE','BF','BG','BH','BI','BJ','BL','BM','BN','BO','BQ','BR','BS','BT','BV','BW','BY','BZ',
    'CA','CC','CD','CF','CG','CH','CI','CK','CL','CM','CN','CO','CR','CU','CV','CW','CX','CY','CZ',
    'DE','DJ','DK','DM','DO','DZ','EC','EE','EG','EH','ER','ES','ET','FI','FJ','FK','FM','FO','FR',
    'GA','GB','GD','GE','GF','GG','GH','GI','GL','GM','GN','GP','GQ','GR','GS','GT','GU','GW','GY',
    'HK','HM','HN','HR','HT','HU','ID','IE','IL','IM','IN','IO','IQ','IR','IS','IT',
    'JE','JM','JO','JP','KE','KG','KH','KI','KM','KN','KP','KR','KW','KY','KZ',
    'LA','LB','LC','LI','LK','LR','LS','LT','LU','LV','LY','MA','MC','MD','ME','MF','MG','MH','MK','ML',
    'MM','MN','MO','MP','MQ','MR','MS','MT','MU','MV','MW','MX','MY','MZ',
    'NA','NC','NE','NF','NG','NI','NL','NO','NP','NR','NU','NZ','OM',
    'PA','PE','PF','PG','PH','PK','PL','PM','PN','PR','PS','PT','PW','PY','QA','RE','RO','RS','RU','RW',
    'SA','SB','SC','SD','SE','SG','SH','SI','SJ','SK','SL','SM','SN','SO','SR','SS','ST','SV','SX','SY','SZ',
    'TC','TD','TF','TG','TH','TJ','TK','TL','TM','TN','TO','TR','TT','TV','TW','TZ',
    'UA','UG','UM','US','UY','UZ','VA','VC','VE','VG','VI','VN','VU','WF','WS','YE','YT','ZA','ZM','ZW',
    'EU','XK'
  ]);

  // ===== COMMON TYPO MAP =====
  const TYPO_MAP = {
    'en-uk': 'en-gb',
    'jp': 'ja',
    'cz': 'cs',
    'sp': 'es',
    'kr': 'ko',
    'dk': 'da',
    'gr': 'el',
    'se': 'sv',
    'br': 'pt-br',
    'ua': 'uk',
    'cn': 'zh',
    'iw': 'he',      // legacy code for Hebrew
    'in': 'id',      // common mistake Indonesian
    'zh-tw': 'zh-hant',
    'zh-cn': 'zh-hans'
  };

  // ===== MAJOR MARKETS (for coverage gap analysis) =====
  // ===== LANGUAGE FLAG ICONS =====
  const LANG_TO_FLAG = {
    'en-us': '\u{1F1FA}\u{1F1F8}', 'en-gb': '\u{1F1EC}\u{1F1E7}', 'en-au': '\u{1F1E6}\u{1F1FA}',
    'en-ca': '\u{1F1E8}\u{1F1E6}', 'en-in': '\u{1F1EE}\u{1F1F3}', 'en-nz': '\u{1F1F3}\u{1F1FF}',
    'en-za': '\u{1F1FF}\u{1F1E6}', 'es-mx': '\u{1F1F2}\u{1F1FD}', 'es-ar': '\u{1F1E6}\u{1F1F7}',
    'es-co': '\u{1F1E8}\u{1F1F4}', 'es-es': '\u{1F1EA}\u{1F1F8}', 'es-cl': '\u{1F1E8}\u{1F1F1}',
    'fr-fr': '\u{1F1EB}\u{1F1F7}', 'fr-ca': '\u{1F1E8}\u{1F1E6}', 'fr-be': '\u{1F1E7}\u{1F1EA}',
    'fr-ch': '\u{1F1E8}\u{1F1ED}', 'de-de': '\u{1F1E9}\u{1F1EA}', 'de-at': '\u{1F1E6}\u{1F1F9}',
    'de-ch': '\u{1F1E8}\u{1F1ED}', 'pt-br': '\u{1F1E7}\u{1F1F7}', 'pt-pt': '\u{1F1F5}\u{1F1F9}',
    'nl-nl': '\u{1F1F3}\u{1F1F1}', 'nl-be': '\u{1F1E7}\u{1F1EA}', 'it-it': '\u{1F1EE}\u{1F1F9}',
    'zh-hans': '\u{1F1E8}\u{1F1F3}', 'zh-hant': '\u{1F1F9}\u{1F1FC}', 'ja-jp': '\u{1F1EF}\u{1F1F5}',
    'ko-kr': '\u{1F1F0}\u{1F1F7}', 'ru-ru': '\u{1F1F7}\u{1F1FA}', 'ar-sa': '\u{1F1F8}\u{1F1E6}',
    'sv-se': '\u{1F1F8}\u{1F1EA}', 'da-dk': '\u{1F1E9}\u{1F1F0}', 'fi-fi': '\u{1F1EB}\u{1F1EE}',
    'nb-no': '\u{1F1F3}\u{1F1F4}', 'nn-no': '\u{1F1F3}\u{1F1F4}', 'pl-pl': '\u{1F1F5}\u{1F1F1}',
    'cs-cz': '\u{1F1E8}\u{1F1FF}', 'hu-hu': '\u{1F1ED}\u{1F1FA}', 'ro-ro': '\u{1F1F7}\u{1F1F4}',
    'tr-tr': '\u{1F1F9}\u{1F1F7}', 'he-il': '\u{1F1EE}\u{1F1F1}', 'th-th': '\u{1F1F9}\u{1F1ED}',
    'vi-vn': '\u{1F1FB}\u{1F1F3}', 'id-id': '\u{1F1EE}\u{1F1E9}', 'ms-my': '\u{1F1F2}\u{1F1FE}',
    'hi-in': '\u{1F1EE}\u{1F1F3}', 'uk-ua': '\u{1F1FA}\u{1F1E6}', 'el-gr': '\u{1F1EC}\u{1F1F7}',
    'en': '\u{1F1EC}\u{1F1E7}', 'fr': '\u{1F1EB}\u{1F1F7}', 'de': '\u{1F1E9}\u{1F1EA}',
    'es': '\u{1F1EA}\u{1F1F8}', 'it': '\u{1F1EE}\u{1F1F9}', 'pt': '\u{1F1F5}\u{1F1F9}',
    'nl': '\u{1F1F3}\u{1F1F1}', 'ru': '\u{1F1F7}\u{1F1FA}', 'ja': '\u{1F1EF}\u{1F1F5}',
    'ko': '\u{1F1F0}\u{1F1F7}', 'zh': '\u{1F1E8}\u{1F1F3}', 'ar': '\u{1F1F8}\u{1F1E6}',
    'sv': '\u{1F1F8}\u{1F1EA}', 'da': '\u{1F1E9}\u{1F1F0}', 'fi': '\u{1F1EB}\u{1F1EE}',
    'nb': '\u{1F1F3}\u{1F1F4}', 'no': '\u{1F1F3}\u{1F1F4}', 'pl': '\u{1F1F5}\u{1F1F1}',
    'cs': '\u{1F1E8}\u{1F1FF}', 'hu': '\u{1F1ED}\u{1F1FA}', 'ro': '\u{1F1F7}\u{1F1F4}',
    'tr': '\u{1F1F9}\u{1F1F7}', 'he': '\u{1F1EE}\u{1F1F1}', 'th': '\u{1F1F9}\u{1F1ED}',
    'vi': '\u{1F1FB}\u{1F1F3}', 'id': '\u{1F1EE}\u{1F1E9}', 'ms': '\u{1F1F2}\u{1F1FE}',
    'hi': '\u{1F1EE}\u{1F1F3}', 'uk': '\u{1F1FA}\u{1F1E6}', 'el': '\u{1F1EC}\u{1F1F7}',
    'bg': '\u{1F1E7}\u{1F1EC}', 'hr': '\u{1F1ED}\u{1F1F7}', 'sk': '\u{1F1F8}\u{1F1F0}',
    'sl': '\u{1F1F8}\u{1F1EE}', 'sr': '\u{1F1F7}\u{1F1F8}', 'ca': '\u{1F1EA}\u{1F1F8}',
    'et': '\u{1F1EA}\u{1F1EA}', 'lv': '\u{1F1F1}\u{1F1FB}', 'lt': '\u{1F1F1}\u{1F1F9}',
    'sw': '\u{1F1F0}\u{1F1EA}', 'tl': '\u{1F1F5}\u{1F1ED}', 'bn': '\u{1F1E7}\u{1F1E9}',
    'x-default': '\u{1F310}'
  };

  function getFlag(hreflangCode) {
    if (!hreflangCode) return '';
    const code = hreflangCode.toLowerCase();
    if (LANG_TO_FLAG[code]) return LANG_TO_FLAG[code];
    const parts = code.split('-');
    if (parts.length >= 2 && parts[1].length === 2) {
      const region = parts[1].toUpperCase();
      return String.fromCodePoint(0x1F1E6 + region.charCodeAt(0) - 65, 0x1F1E6 + region.charCodeAt(1) - 65);
    }
    if (LANG_TO_FLAG[parts[0]]) return LANG_TO_FLAG[parts[0]];
    return '';
  }

  // Return an <img> tag for the flag using Twemoji CDN (works on Windows)
  function getFlagImg(hreflangCode) {
    if (!hreflangCode) return '';
    const code = hreflangCode.toLowerCase();

    // x-default → globe
    if (code === 'x-default') {
      return '<img class="flag-emoji" src="https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/1f310.svg" alt="\u{1F310}">';
    }

    // Determine region code
    let region = null;
    const parts = code.split('-');

    // zh-hans / zh-hant special cases
    if (code === 'zh-hans') region = 'CN';
    else if (code === 'zh-hant') region = 'TW';
    else if (parts.length >= 2 && parts[1].length === 2) {
      region = parts[1].toUpperCase();
    } else {
      // Language-only → default country
      const LANG_COUNTRY = {
        en:'GB', fr:'FR', de:'DE', es:'ES', it:'IT', pt:'PT', nl:'NL',
        ru:'RU', ja:'JP', ko:'KR', zh:'CN', ar:'SA', sv:'SE', da:'DK',
        fi:'FI', nb:'NO', no:'NO', pl:'PL', cs:'CZ', hu:'HU', ro:'RO',
        tr:'TR', he:'IL', th:'TH', vi:'VN', id:'ID', ms:'MY', hi:'IN',
        uk:'UA', el:'GR', bg:'BG', hr:'HR', sk:'SK', sl:'SI', sr:'RS',
        ca:'ES', et:'EE', lv:'LV', lt:'LT', sw:'KE', tl:'PH', bn:'BD'
      };
      region = LANG_COUNTRY[parts[0]];
    }

    if (!region) return '';

    const cp1 = (0x1F1E6 + region.charCodeAt(0) - 65).toString(16);
    const cp2 = (0x1F1E6 + region.charCodeAt(1) - 65).toString(16);
    const alt = getFlag(hreflangCode);
    return `<img class="flag-emoji" src="https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/${cp1}-${cp2}.svg" alt="${alt}">`;
  }

  // Return raw Twemoji CDN URL for a hreflang code (for canvas drawing)
  function getFlagUrl(hreflangCode) {
    if (!hreflangCode) return null;
    const code = hreflangCode.toLowerCase();
    if (code === 'x-default') return 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/1f310.svg';
    let region = null;
    const parts = code.split('-');
    if (code === 'zh-hans') region = 'CN';
    else if (code === 'zh-hant') region = 'TW';
    else if (parts.length >= 2 && parts[1].length === 2) region = parts[1].toUpperCase();
    else {
      const LC = { en:'GB',fr:'FR',de:'DE',es:'ES',it:'IT',pt:'PT',nl:'NL',ru:'RU',ja:'JP',ko:'KR',zh:'CN',ar:'SA',sv:'SE',da:'DK',fi:'FI',nb:'NO',no:'NO',pl:'PL',cs:'CZ',hu:'HU',ro:'RO',tr:'TR',he:'IL',th:'TH',vi:'VN',id:'ID',ms:'MY',hi:'IN',uk:'UA',el:'GR',bg:'BG',hr:'HR',sk:'SK',sl:'SI',sr:'RS',ca:'ES',et:'EE',lv:'LV',lt:'LT',sw:'KE',tl:'PH',bn:'BD' };
      region = LC[parts[0]];
    }
    if (!region) return null;
    const cp1 = (0x1F1E6 + region.charCodeAt(0) - 65).toString(16);
    const cp2 = (0x1F1E6 + region.charCodeAt(1) - 65).toString(16);
    return `https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/${cp1}-${cp2}.svg`;
  }

  // ===== URL NORMALIZATION =====
  const _normalizeCache = new Map();
  function normalizeUrl(url) {
    if (_normalizeCache.has(url)) return _normalizeCache.get(url);
    let result;
    try {
      const u = new URL(url);
      let path = u.pathname;
      if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
      result = u.origin + path + u.search;
    } catch {
      result = url;
    }
    _normalizeCache.set(url, result);
    return result;
  }

  function shortenUrl(url) {
    try {
      const u = new URL(url);
      const path = u.pathname + u.search || '/';
      // Show hostname for root-path URLs (e.g. uk.gymshark.com vs au.gymshark.com)
      if (path === '/') return u.hostname;
      return path;
    } catch {
      return url;
    }
  }

  // ===== PARSE HREFLANG FROM HTML =====
  function parseHreflangFromHtml(html, baseUrl) {
    const tags = [];
    const linkRegex = /<link[^>]+rel\s*=\s*["']alternate["'][^>]*>/gi;
    let match;

    while ((match = linkRegex.exec(html)) !== null) {
      const tag = match[0];
      const hreflangMatch = tag.match(/hreflang\s*=\s*["']([^"']+)["']/i);
      const hrefMatch = tag.match(/href\s*=\s*["']([^"']+)["']/i);
      if (hreflangMatch && hrefMatch) {
        let href = hrefMatch[1];
        try { href = new URL(href, baseUrl).href; } catch {}
        tags.push({ hreflang: hreflangMatch[1].toLowerCase(), href });
      }
    }

    // Parse canonical
    const canonicalMatch = html.match(/<link[^>]+rel\s*=\s*["']canonical["'][^>]+href\s*=\s*["']([^"']+)["']/i)
      || html.match(/<link[^>]+href\s*=\s*["']([^"']+)["'][^>]+rel\s*=\s*["']canonical["']/i);
    const canonical = canonicalMatch ? canonicalMatch[1] : null;

    // Parse <html lang>
    const htmlLangMatch = html.match(/<html[^>]+lang\s*=\s*["']([^"']+)["']/i);
    const htmlLang = htmlLangMatch ? htmlLangMatch[1].toLowerCase().trim() : '';

    // Parse noindex
    const robotsMatch = html.match(/<meta[^>]+name\s*=\s*["']robots["'][^>]+content\s*=\s*["']([^"']+)["']/i)
      || html.match(/<meta[^>]+content\s*=\s*["']([^"']+)["'][^>]+name\s*=\s*["']robots["']/i);
    const isNoindex = robotsMatch ? robotsMatch[1].toLowerCase().includes('noindex') : false;

    return { tags, canonical, htmlLang, isNoindex };
  }

  // ===== VALIDATE HREFLANG VALUE =====
  function validateHreflangValue(value) {
    if (value === 'x-default') return { valid: true };

    const parts = value.toLowerCase().split('-');
    const lang = parts[0];
    const region = parts.length > 1 ? parts.slice(1).join('-') : null;

    // Check for known typos first
    if (TYPO_MAP[value]) {
      return { valid: false, reason: `"${value}" looks like a typo — did you mean "${TYPO_MAP[value]}"?`, typo: TYPO_MAP[value] };
    }

    if (!VALID_LANGS.has(value) && !VALID_LANGS.has(lang)) {
      return { valid: false, reason: `"${lang}" is not a valid ISO 639-1 language code` };
    }

    if (region && region.length === 2 && !VALID_REGIONS.has(region.toUpperCase())) {
      return { valid: false, reason: `"${region.toUpperCase()}" is not a valid ISO 3166-1 region code` };
    }

    return { valid: true };
  }

  // ===== MAIN SCAN =====
  async function runScan() {
    try {
      // Step 1: Get active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) throw new Error('No active tab found');

      // Check for restricted pages
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') ||
          tab.url.startsWith('about:') || tab.url.startsWith('edge://')) {
        showState('error');
        $('error-body').textContent = 'Cannot scan browser internal pages. Navigate to a website to check its hreflang tags.';
        return;
      }

      // Step 2: Extract hreflang from the active tab
      $('loading-detail').textContent = 'Extracting hreflang tags from this page';
      const extraction = await chrome.runtime.sendMessage({
        type: 'EXTRACT_HREFLANG',
        tabId: tab.id
      });

      if (!extraction.ok) throw new Error(extraction.error || 'Failed to extract hreflang tags');

      const { hreflangTags, rawHreflangs, canonical, pageUrl, htmlLang, isNoindex, outsideHeadCount } = extraction.data;

      // Track detection sources
      const sources = { html: false, header: false, sitemap: false };
      let sitemapData = null;

      // HTML hreflang tags from DOM
      let sourceTags = [];
      if (hreflangTags && hreflangTags.length > 0) {
        sources.html = true;
        sourceTags = hreflangTags.map(t => ({
          hreflang: t.hreflang.toLowerCase(),
          href: t.href,
          source: 'html'
        }));
      }

      // Step 2b: Check HTTP headers (fetch the source page for headers)
      $('loading-detail').textContent = 'Checking HTTP headers...';
      let headerTags = [];
      let sourceResponseTime = null;
      let sourceContentLanguage = '';
      try {
        const headerResult = await chrome.runtime.sendMessage({ type: 'FETCH_PAGE', url: pageUrl });
        sourceResponseTime = headerResult.responseTime || null;
        sourceContentLanguage = headerResult.contentLanguage || '';
        if (headerResult.ok && headerResult.headerHreflangTags && headerResult.headerHreflangTags.length > 0) {
          sources.header = true;
          headerTags = headerResult.headerHreflangTags.map(t => ({
            hreflang: t.hreflang.toLowerCase(),
            href: t.href,
            source: 'header'
          }));
        }
      } catch (e) { /* ignore header fetch errors */ }

      // Step 2c: Check XML sitemap
      $('loading-detail').textContent = 'Checking sitemap...';
      try {
        const sitemapResult = await chrome.runtime.sendMessage({ type: 'FETCH_SITEMAP', url: pageUrl });
        if (sitemapResult.ok && sitemapResult.found && sitemapResult.entries) {
          sitemapData = sitemapResult;
          // Check if sitemap has entries for the current page
          const pageEntries = findSitemapEntries(sitemapResult.entries, pageUrl);
          if (pageEntries.length > 0) {
            sources.sitemap = true;
          }
        }
      } catch (e) { /* ignore sitemap errors */ }

      // Merge all tags — HTML takes priority, then headers, then sitemap
      const mergedTags = mergeTags(sourceTags, headerTags, sitemapData, pageUrl);

      // No hreflang tags found from any source
      if (mergedTags.length === 0) {
        // Update badge to empty
        try {
          await chrome.runtime.sendMessage({ type: 'SET_BADGE', count: 0, tabId: tab.id });
        } catch {}
        showState('empty');
        return;
      }

      // Detect relative URLs on the source page
      const hasRelativeUrls = rawHreflangs && rawHreflangs.some(raw => {
        if (!raw) return false;
        return !raw.startsWith('http://') && !raw.startsWith('https://') && !raw.startsWith('//');
      });

      // Step 3: Build cluster — fetch each URL
      const allUrls = [...new Set(mergedTags.map(t => t.href))];
      $('loading-detail').textContent = `Scanning ${allUrls.length} pages in the cluster...`;

      const clusterData = new Map(); // normUrl -> page data

      // Add source page data
      const sourceNorm = normalizeUrl(pageUrl);
      clusterData.set(sourceNorm, {
        tags: mergedTags,
        canonical,
        status: 200,
        fetchOk: true,
        url: pageUrl,
        htmlLang,
        isNoindex,
        redirected: false,
        requestedUrl: pageUrl,
        finalUrl: pageUrl,
        hreflangOnSource: mergedTags.find(t => normalizeUrl(t.href) === sourceNorm)?.hreflang || null,
        headerTags: headerTags,
        sources: { ...sources },
        responseTime: sourceResponseTime,
        contentLanguage: sourceContentLanguage
      });

      // Fetch all other pages in parallel
      const fetchPromises = allUrls
        .filter(url => normalizeUrl(url) !== sourceNorm)
        .map(async url => {
          $('loading-detail').textContent = `Fetching ${shortenUrl(url)}`;
          const result = await chrome.runtime.sendMessage({ type: 'FETCH_PAGE', url });
          const normUrl = normalizeUrl(url);

          if (result.ok && result.status === 200) {
            const parsed = parseHreflangFromHtml(result.html, url);

            // Merge with any HTTP header tags from this page
            let pageTags = parsed.tags.map(t => ({ hreflang: t.hreflang.toLowerCase(), href: t.href, source: 'html' }));
            if (result.headerHreflangTags && result.headerHreflangTags.length > 0) {
              for (const ht of result.headerHreflangTags) {
                const exists = pageTags.some(t => t.hreflang === ht.hreflang.toLowerCase() && normalizeUrl(t.href) === normalizeUrl(ht.href));
                if (!exists) {
                  pageTags.push({ hreflang: ht.hreflang.toLowerCase(), href: ht.href, source: 'header' });
                }
              }
            }

            clusterData.set(normUrl, {
              tags: pageTags,
              canonical: parsed.canonical,
              status: result.status,
              fetchOk: true,
              url,
              htmlLang: parsed.htmlLang || '',
              isNoindex: parsed.isNoindex || false,
              redirected: result.redirected || false,
              requestedUrl: result.requestedUrl || url,
              finalUrl: result.finalUrl || url,
              headerTags: result.headerHreflangTags || [],
              responseTime: result.responseTime || null,
              contentLanguage: result.contentLanguage || ''
            });
          } else {
            clusterData.set(normUrl, {
              tags: [],
              canonical: null,
              status: result.status || 0,
              fetchOk: false,
              url,
              htmlLang: '',
              isNoindex: false,
              redirected: result.redirected || false,
              requestedUrl: result.requestedUrl || url,
              finalUrl: result.finalUrl || url,
              error: result.error || `HTTP ${result.status}`,
              headerTags: [],
              responseTime: result.responseTime || null,
              contentLanguage: ''
            });
          }
        });

      await Promise.allSettled(fetchPromises);

      // Assign hreflang values from source tags to cluster entries
      for (const tag of mergedTags) {
        const normHref = normalizeUrl(tag.href);
        const entry = clusterData.get(normHref);
        if (entry && !entry.hreflangOnSource) {
          entry.hreflangOnSource = tag.hreflang;
        }
      }

      // Step 4: Run validation
      $('loading-detail').textContent = 'Analyzing cluster health...';
      const issues = validateCluster(mergedTags, clusterData, pageUrl, canonical, sitemapData, hasRelativeUrls, outsideHeadCount || 0);

      // Step 5: Calculate score
      const score = calculateScore(issues, clusterData.size);

      // Step 6: Update badge
      try {
        await chrome.runtime.sendMessage({ type: 'SET_BADGE', count: issues.length, tabId: tab.id });
      } catch {}

      // Store for exports
      _exportData = { score, issues, clusterData, sourceTags: mergedTags, pageUrl, sources, sitemapData };

      // Step 8: Render
      renderResults(score, issues, clusterData, mergedTags, sources, sitemapData);

    } catch (err) {
      console.error('Scan error:', err);
      showState('error');
      $('error-body').textContent = err.message || 'Something went wrong while scanning this page.';
    }
  }

  // ===== MERGE TAGS FROM MULTIPLE SOURCES =====
  function mergeTags(htmlTags, headerTags, sitemapResult, pageUrl) {
    const merged = [...htmlTags];
    const seen = new Set(htmlTags.map(t => `${t.hreflang}::${normalizeUrl(t.href)}`));

    // Add header tags not already in HTML
    for (const ht of headerTags) {
      const key = `${ht.hreflang}::${normalizeUrl(ht.href)}`;
      if (!seen.has(key)) {
        merged.push(ht);
        seen.add(key);
      }
    }

    // Add sitemap tags not already present
    if (sitemapResult && sitemapResult.entries) {
      const pageEntries = findSitemapEntries(sitemapResult.entries, pageUrl);
      for (const st of pageEntries) {
        const key = `${st.hreflang}::${normalizeUrl(st.href)}`;
        if (!seen.has(key)) {
          merged.push({ hreflang: st.hreflang, href: st.href, source: 'sitemap' });
          seen.add(key);
        }
      }
    }

    return merged;
  }

  // ===== FIND SITEMAP ENTRIES FOR A URL =====
  function findSitemapEntries(entries, pageUrl) {
    const norm = normalizeUrl(pageUrl);
    // entries is an object { url: [{ hreflang, href }] }
    for (const [url, tags] of Object.entries(entries)) {
      if (normalizeUrl(url) === norm) {
        return tags;
      }
    }
    return [];
  }

  // ===== VALIDATION ENGINE =====
  function validateCluster(sourceTags, clusterData, sourcePageUrl, sourceCanonical, sitemapData, hasRelativeUrls, outsideHeadCount) {
    const issues = [];
    const sourceNorm = normalizeUrl(sourcePageUrl);

    // 1. Check for valid hreflang codes + typo detection
    for (const [url, data] of clusterData) {
      for (const tag of data.tags) {
        const validation = validateHreflangValue(tag.hreflang);
        if (!validation.valid) {
          issues.push({
            severity: validation.typo ? 'warning' : 'critical',
            title: validation.typo ? 'Likely hreflang typo' : 'Invalid hreflang code',
            description: validation.typo
              ? `The value "${tag.hreflang}" on ${shortenUrl(data.url)} looks like a common typo. The correct code is probably "${validation.typo}".`
              : `The value "${tag.hreflang}" on ${shortenUrl(data.url)} is not valid. ${validation.reason}.`,
            pages: [data.url],
            _codes: [tag.hreflang],
            fix: validation.typo
              ? `Change hreflang="${tag.hreflang}" to hreflang="${validation.typo}" on this page.`
              : `Use a valid ISO 639-1 language code, optionally followed by an ISO 3166-1 region code (e.g., "en", "en-gb", "pt-br").`,
            _typoSuggestion: validation.typo || null
          });
        }
      }
    }

    // 2. Check for duplicate hreflang values on each page
    for (const [url, data] of clusterData) {
      if (!data.fetchOk) continue;
      const seen = new Map();
      for (const tag of data.tags) {
        if (seen.has(tag.hreflang)) {
          issues.push({
            severity: 'critical',
            title: 'Duplicate hreflang value',
            description: `The page ${shortenUrl(data.url)} has multiple hreflang tags for "${tag.hreflang}". Search engines won't know which to use.`,
            pages: [data.url],
            _codes: [tag.hreflang],
            fix: `Remove the duplicate. Each hreflang value should appear only once per page. Keep the one with the correct target URL.`
          });
        }
        seen.set(tag.hreflang, tag.href);
      }
    }

    // 3. Check self-referencing tags
    for (const [url, data] of clusterData) {
      if (!data.fetchOk) continue;
      const hasSelfRef = data.tags.some(t => normalizeUrl(t.href) === url);
      if (!hasSelfRef && data.tags.length > 0) {
        issues.push({
          severity: 'critical',
          title: 'Missing self-referencing tag',
          description: `The page ${shortenUrl(data.url)} has hreflang tags but none of them point back to itself. Every page must include itself in its own hreflang set.`,
          pages: [data.url],
          fix: `Add a <link rel="alternate" hreflang="..." href="${data.url}"> tag where the href matches this page's URL exactly.`
        });
      }
    }

    // 4. Check return tags (bidirectional)
    for (const [url, data] of clusterData) {
      if (!data.fetchOk) continue;
      for (const tag of data.tags) {
        const targetNorm = normalizeUrl(tag.href);
        if (targetNorm === url) continue;

        const targetData = clusterData.get(targetNorm);
        if (!targetData) continue;
        if (!targetData.fetchOk) continue;

        const hasReturnTag = targetData.tags.some(t => normalizeUrl(t.href) === url);
        if (!hasReturnTag) {
          const alreadyReported = issues.some(i =>
            i.title === 'Missing return tag' &&
            i._key === `${targetNorm}->${url}`
          );
          if (!alreadyReported) {
            issues.push({
              severity: 'critical',
              title: 'Missing return tag',
              description: `${shortenUrl(data.url)} links to ${shortenUrl(tag.href)} with hreflang="${tag.hreflang}", but the target page doesn't link back. Hreflang must be bidirectional.`,
              pages: [data.url, tag.href],
              fix: `Add a <link rel="alternate" hreflang="..." href="${data.url}"> tag on ${shortenUrl(tag.href)} pointing back to ${shortenUrl(data.url)}.`,
              _key: `${url}->${targetNorm}`
            });
          }
        }
      }
    }

    // 5. Enhanced x-default checks
    const xDefaultTag = sourceTags.find(t => t.hreflang === 'x-default');
    if (!xDefaultTag) {
      issues.push({
        severity: 'warning',
        title: 'No x-default tag',
        description: 'The cluster doesn\'t specify a fallback page for users whose language doesn\'t match any hreflang variant. Search engines use x-default as the catch-all.',
        pages: [],
        fix: 'Add an x-default hreflang tag pointing to your language selector page or primary market version.'
      });
    } else {
      const xDefaultUrl = normalizeUrl(xDefaultTag.href);
      if (!clusterData.has(xDefaultUrl)) {
        issues.push({
          severity: 'warning',
          title: 'x-default URL not in cluster',
          description: `The x-default tag points to ${shortenUrl(xDefaultTag.href)}, which is not part of the hreflang cluster. This URL should be reachable and ideally be one of the cluster pages.`,
          pages: [xDefaultTag.href],
          fix: 'Either add the x-default URL to the cluster, or change x-default to point to one of the existing cluster pages.'
        });
      } else {
        const xDefaultEntry = clusterData.get(xDefaultUrl);
        if (xDefaultEntry && xDefaultEntry.redirected) {
          // Detect geo-redirect: x-default redirects to the source page's origin
          let isGeo = false;
          try {
            const xOrigin = new URL(xDefaultTag.href).origin;
            const finalOrigin = new URL(xDefaultEntry.finalUrl).origin;
            const srcOrigin = new URL(sourcePageUrl).origin;
            isGeo = finalOrigin === srcOrigin && xOrigin !== srcOrigin;
          } catch {}

          if (isGeo) {
            issues.push({
              severity: 'info',
              title: 'Possible geo-redirect',
              description: `The x-default URL ${shortenUrl(xDefaultTag.href)} redirects to ${shortenUrl(xDefaultEntry.finalUrl)}. This looks like a geo-redirect to your current location — the x-default URL is likely correct for search engines.`,
              pages: [xDefaultTag.href],
              fix: `Verify that search engine crawlers can access ${shortenUrl(xDefaultTag.href)} without being geo-redirected. No change needed if crawlers reach the intended fallback page.`
            });
          } else {
            issues.push({
              severity: 'warning',
              title: 'x-default URL redirects',
              description: `The x-default URL ${shortenUrl(xDefaultTag.href)} redirects to ${shortenUrl(xDefaultEntry.finalUrl)}. The fallback page should be directly accessible.`,
              pages: [xDefaultTag.href],
              fix: `Update the x-default href to point to the final destination: ${xDefaultEntry.finalUrl}`
            });
          }
        }
      }
    }

    // 6. Check unreachable pages
    for (const [url, data] of clusterData) {
      if (!data.fetchOk) {
        issues.push({
          severity: 'critical',
          title: 'Unreachable page',
          description: `${shortenUrl(data.url)} returned ${data.error || 'an error'}. Pages in an hreflang cluster must be accessible — broken links undermine the entire set.`,
          pages: [data.url],
          fix: `Check the URL is correct, the server is responding, and the page returns HTTP 200. If the page was removed, remove its hreflang tag from all other pages.`
        });
      }
    }

    // 7. Check canonical vs hreflang alignment
    for (const [url, data] of clusterData) {
      if (!data.fetchOk || !data.canonical) continue;
      // Skip pages that redirected to a different URL — canonical belongs to the redirected-to page
      if (data.redirected && data.finalUrl && normalizeUrl(data.finalUrl) !== url) continue;
      const canonicalNorm = normalizeUrl(data.canonical);
      if (canonicalNorm !== url) {
        issues.push({
          severity: 'warning',
          title: 'Canonical mismatch',
          description: `${shortenUrl(data.url)} has a canonical tag pointing to ${shortenUrl(data.canonical)}, which differs from its own URL. Search engines may ignore the hreflang tags on this page.`,
          pages: [data.url],
          fix: `Either update the canonical to be self-referencing, or move the hreflang tags to the canonical URL. The hreflang href and canonical should agree.`
        });
      }
    }

    // 8. Check inconsistent URL schemes
    const schemes = new Set();
    for (const tag of sourceTags) {
      try { schemes.add(new URL(tag.href).protocol); } catch {}
    }
    if (schemes.size > 1) {
      issues.push({
        severity: 'warning',
        title: 'Mixed URL schemes',
        description: 'The hreflang cluster mixes http:// and https:// URLs. This can confuse search engines and cause them to ignore some tags.',
        pages: [],
        fix: 'Use the same protocol (preferably https://) for all hreflang URLs.'
      });
    }

    // 9. Check for inconsistent tag counts across pages
    const tagCounts = [];
    for (const [url, data] of clusterData) {
      if (data.fetchOk) tagCounts.push(data.tags.length);
    }
    if (tagCounts.length > 1) {
      const maxCount = Math.max(...tagCounts);
      const minCount = Math.min(...tagCounts);
      if (maxCount > 0 && minCount === 0) {
        const pagesWithout = [...clusterData.entries()]
          .filter(([, d]) => d.fetchOk && d.tags.length === 0)
          .map(([, d]) => d.url);
        issues.push({
          severity: 'critical',
          title: 'Missing hreflang tags',
          description: `${pagesWithout.length} page(s) in the cluster have no hreflang tags at all. Every page in the cluster must include the full set of hreflang tags.`,
          pages: pagesWithout,
          fix: 'Add the complete set of hreflang <link> tags to every page in the cluster. Each page should reference all other pages and itself.'
        });
      } else if (maxCount - minCount > 1 && minCount > 0) {
        issues.push({
          severity: 'warning',
          title: 'Inconsistent tag count',
          description: `Pages in this cluster have different numbers of hreflang tags (${minCount} to ${maxCount}). Each page should have the same complete set.`,
          pages: [],
          fix: 'Ensure every page lists the exact same set of hreflang tags. A missing tag means search engines may not associate those pages correctly.'
        });
      }
    }

    // 10. NEW: Redirect chain detection
    const sourceOrigin = (() => { try { return new URL(sourcePageUrl).origin; } catch { return ''; } })();
    for (const [url, data] of clusterData) {
      if (data.redirected && data.requestedUrl && data.finalUrl) {
        if (normalizeUrl(data.requestedUrl) !== normalizeUrl(data.finalUrl)) {
          // Detect geo-redirect: redirects to source page's origin from a different origin
          let isGeo = false;
          try {
            const reqOrigin = new URL(data.requestedUrl).origin;
            const finalOrigin = new URL(data.finalUrl).origin;
            isGeo = finalOrigin === sourceOrigin && reqOrigin !== sourceOrigin;
          } catch {}

          if (isGeo) {
            issues.push({
              severity: 'info',
              title: 'Possible geo-redirect',
              description: `${shortenUrl(data.requestedUrl)} redirects to ${shortenUrl(data.finalUrl)}. This looks like a geo-redirect to your current location. Search engine crawlers are typically not geo-redirected, so this may not affect indexing.`,
              pages: [data.requestedUrl],
              fix: `Verify that search engine crawlers (e.g. Googlebot) can access ${shortenUrl(data.requestedUrl)} without being redirected. Geo-redirects for users are OK, but crawlers need direct access.`,
              _redirectFrom: data.requestedUrl,
              _redirectTo: data.finalUrl
            });
          } else {
            issues.push({
              severity: 'warning',
              title: 'Hreflang URL redirects',
              description: `${shortenUrl(data.requestedUrl)} redirects to ${shortenUrl(data.finalUrl)}. Hreflang tags should point to the final URL, not a redirecting one. Search engines may drop redirecting hreflang entries.`,
              pages: [data.requestedUrl],
              fix: `Update the hreflang href to point directly to the final destination: ${data.finalUrl}`,
              _redirectFrom: data.requestedUrl,
              _redirectTo: data.finalUrl
            });
          }
        }
      }
    }

    // 11. NEW: <html lang> mismatch detection
    for (const [url, data] of clusterData) {
      if (!data.fetchOk || !data.htmlLang) continue;
      // Skip pages that redirected to a different URL — lang belongs to the redirected-to page
      if (data.redirected && data.finalUrl && normalizeUrl(data.finalUrl) !== url) continue;
      const assignedHreflang = data.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === url)?.hreflang;
      if (!assignedHreflang || assignedHreflang === 'x-default') continue;

      // Compare base language codes
      const htmlBase = data.htmlLang.split('-')[0].toLowerCase();
      const hreflangBase = assignedHreflang.split('-')[0].toLowerCase();

      if (htmlBase && hreflangBase && htmlBase !== hreflangBase) {
        issues.push({
          severity: 'warning',
          title: 'HTML lang mismatch',
          description: `${shortenUrl(data.url)} has <html lang="${data.htmlLang}"> but its hreflang value is "${assignedHreflang}". These should match to avoid mixed signals to search engines.`,
          pages: [data.url],
          fix: `Either change the <html lang> attribute to match the hreflang value, or update the hreflang tag to match the actual page language.`,
          _htmlLang: data.htmlLang,
          _hreflang: assignedHreflang
        });
      }
    }

    // 12. NEW: Noindex + hreflang conflict
    for (const [url, data] of clusterData) {
      if (!data.fetchOk) continue;
      if (data.isNoindex && data.tags.length > 0) {
        issues.push({
          severity: 'critical',
          title: 'Noindex with hreflang',
          description: `${shortenUrl(data.url)} is marked as noindex but has hreflang tags. Search engines won't index this page, making the hreflang tags useless and potentially breaking the cluster.`,
          pages: [data.url],
          fix: 'Either remove the noindex directive (if the page should be indexed), or remove the hreflang tags from all pages that reference this URL.'
        });
      }
    }

    // 13. NEW: Relative URL detection
    if (hasRelativeUrls) {
      issues.push({
        severity: 'warning',
        title: 'Relative URLs detected',
        description: 'Some hreflang tags on the source page use relative URLs instead of absolute URLs. While browsers resolve them, search engines strongly prefer absolute URLs in hreflang tags.',
        pages: [sourcePageUrl],
        fix: 'Change all hreflang href values to absolute URLs starting with https:// (e.g., href="https://example.com/fr/" instead of href="/fr/").'
      });
    }

    // 14. NEW: Sitemap vs HTML conflict detection
    if (sitemapData && sitemapData.found && sitemapData.entries) {
      const pageEntries = findSitemapEntries(sitemapData.entries, sourcePageUrl);
      if (pageEntries.length > 0) {
        const htmlOnly = sourceTags.filter(t => t.source === 'html');
        // Check for conflicts between sitemap and HTML
        for (const sEntry of pageEntries) {
          const htmlMatch = htmlOnly.find(h => h.hreflang === sEntry.hreflang);
          if (htmlMatch && normalizeUrl(htmlMatch.href) !== normalizeUrl(sEntry.href)) {
            issues.push({
              severity: 'warning',
              title: 'Sitemap/HTML conflict',
              description: `For hreflang="${sEntry.hreflang}", the HTML points to ${shortenUrl(htmlMatch.href)} but the sitemap points to ${shortenUrl(sEntry.href)}. These should be identical.`,
              pages: [sourcePageUrl],
              fix: `Ensure the hreflang href for "${sEntry.hreflang}" is the same in both the HTML <link> tags and the XML sitemap.`
            });
          }
        }
      }
    }

    // 15. Hreflang tags outside <head>
    if (outsideHeadCount > 0) {
      issues.push({
        severity: 'warning',
        title: 'Hreflang tags outside <head>',
        description: `${outsideHeadCount} hreflang <link> tag(s) on the source page are placed inside <body> instead of <head>. This is invalid HTML and search engines may ignore them.`,
        pages: [sourcePageUrl],
        fix: 'Move all <link rel="alternate" hreflang="..."> tags into the <head> section of your HTML document.'
      });
    }

    // 16. Content-Language header mismatch
    for (const [url, data] of clusterData) {
      if (!data.fetchOk || !data.contentLanguage) continue;
      // Skip pages that redirected to a different URL — header belongs to the redirected-to page
      if (data.redirected && data.finalUrl && normalizeUrl(data.finalUrl) !== url) continue;
      const assignedHreflang = data.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === url)?.hreflang;
      if (!assignedHreflang || assignedHreflang === 'x-default') continue;
      const clBase = data.contentLanguage.split('-')[0].split(',')[0].trim().toLowerCase();
      const hreflangBase = assignedHreflang.split('-')[0].toLowerCase();
      if (clBase && hreflangBase && clBase !== hreflangBase) {
        issues.push({
          severity: 'info',
          title: 'Content-Language mismatch',
          description: `${shortenUrl(data.url)} sends Content-Language: ${data.contentLanguage} but its hreflang value is "${assignedHreflang}". Aligning these signals helps search engines.`,
          pages: [data.url],
          fix: 'Update the Content-Language HTTP header to match the hreflang value, or vice versa.'
        });
      }
    }

    return issues;
  }

  // ===== SCORING =====
  function calculateScore(issues, pageCount) {
    if (pageCount === 0) return 100;

    let deductions = 0;
    for (const issue of issues) {
      switch (issue.severity) {
        case 'critical':
          deductions += 12;
          break;
        case 'warning':
          deductions += 5;
          break;
        case 'info':
          deductions += 1;
          break;
      }
    }

    return Math.max(0, Math.min(100, 100 - deductions));
  }

  // ===== RENDER RESULTS =====
  function renderResults(score, issues, clusterData, sourceTags, sources, sitemapData) {
    showState('results');

    // Detection sources
    renderDetectionSources(sources, sitemapData);

    // Audited URL banner
    const pageUrl = _exportData?.pageUrl || '';
    const auditedEl = $('audited-url');
    if (pageUrl) {
      auditedEl.style.display = 'block';
      auditedEl.innerHTML = `<span class="audited-label">Audited URL:</span><span class="audited-href" title="${escHtml(pageUrl)}">${escHtml(pageUrl)}</span>`;
    }

    // Score ring animation
    const circumference = 2 * Math.PI * 52;
    const offset = circumference - (score / 100) * circumference;
    const ringFill = $('score-ring-fill');

    let ringColor = '#43A047'; // green for good
    if (score < 50) ringColor = '#E53935'; // red for bad
    else if (score < 80) ringColor = '#F2BC63'; // gold for okay

    ringFill.style.stroke = ringColor;
    setTimeout(() => {
      ringFill.style.strokeDashoffset = offset;
    }, 100);

    // Animate score number
    animateNumber($('score-number'), score, 800);

    // Stats
    const languages = new Set(sourceTags.map(t => t.hreflang).filter(h => h !== 'x-default'));
    $('stat-pages').textContent = clusterData.size;
    $('stat-issues').textContent = issues.length;
    $('stat-languages').textContent = languages.size;

    // Cluster Matrix
    renderClusterMatrix(clusterData, sourceTags);
    $('btn-export-matrix').style.display = clusterData.size >= 2 ? '' : 'none';

    // Issues — consolidate duplicates by title before rendering
    if (issues.length > 0) {
      $('issues-section').style.display = '';
      $('all-clear').style.display = 'none';

      const consolidated = consolidateIssues(issues);

      const grouped = { critical: [], warning: [], info: [] };
      for (const issue of consolidated) {
        (grouped[issue.severity] || grouped.info).push(issue);
      }

      const issuesList = $('issues-list');
      issuesList.innerHTML = '';

      for (const severity of ['critical', 'warning', 'info']) {
        for (const issue of grouped[severity]) {
          issuesList.appendChild(createIssueCard(issue));
        }
      }
    } else {
      $('issues-section').style.display = 'none';
      $('all-clear').style.display = '';
    }

    // Page details
    renderPageDetails(clusterData, sourceTags, issues);
  }

  // ===== CONSOLIDATE REPEATED ISSUES =====
  function consolidateIssues(issues) {
    const groups = new Map(); // title -> merged issue

    for (const issue of issues) {
      const key = issue.title;

      if (groups.has(key)) {
        const existing = groups.get(key);
        // Merge pages (deduplicate)
        for (const p of issue.pages) {
          if (!existing.pages.includes(p)) {
            existing.pages.push(p);
          }
        }
        // Merge codes (deduplicate)
        if (issue._codes) {
          if (!existing._codes) existing._codes = [];
          for (const c of issue._codes) {
            if (!existing._codes.includes(c)) existing._codes.push(c);
          }
        }
        existing._count++;
      } else {
        groups.set(key, {
          ...issue,
          pages: [...issue.pages],
          _codes: issue._codes ? [...issue._codes] : undefined,
          _count: 1
        });
      }
    }

    // Rewrite descriptions for consolidated issues
    const result = [];
    for (const [title, issue] of groups) {
      if (issue._count > 1) {
        // Rewrite to summarise the group
        switch (title) {
          case 'Missing self-referencing tag':
            issue.description = `${issue._count} pages have hreflang tags but none pointing back to themselves. Every page must include itself in its own hreflang set.`;
            break;
          case 'Missing return tag':
            issue.description = `${issue._count} bidirectional links are broken — pages reference each other but the target doesn't link back. Hreflang must be reciprocal.`;
            break;
          case 'Unreachable page':
            issue.description = `${issue._count} pages in the cluster returned errors. Broken pages undermine the entire hreflang set.`;
            break;
          case 'Canonical mismatch':
            issue.description = `${issue._count} pages have canonical tags pointing to different URLs. Search engines may ignore their hreflang tags.`;
            break;
          case 'Duplicate hreflang value':
            issue.description = `${issue._count} pages have duplicate hreflang values. Each language code should appear only once per page.`;
            break;
          case 'Invalid hreflang code':
            issue.description = `${issue._count} invalid hreflang codes found across the cluster. Use valid ISO 639-1 language codes.`;
            break;
          case 'Likely hreflang typo':
            issue.description = `${issue._count} likely typos found in hreflang values across the cluster.`;
            break;
          case 'Noindex with hreflang':
            issue.description = `${issue._count} pages are marked noindex but have hreflang tags — search engines won't index them, making the tags useless.`;
            break;
          case 'HTML lang mismatch':
            issue.description = `${issue._count} pages have <html lang> attributes that don't match their hreflang values.`;
            break;
          case 'Hreflang URL redirects':
            issue.description = `${issue._count} hreflang URLs redirect to different destinations. Tags should point to the final URL directly.`;
            break;
          case 'Content-Language mismatch':
            issue.description = `${issue._count} pages have Content-Language headers that don't match their hreflang values.`;
            break;
          case 'Hreflang tags outside <head>':
            issue.description = `${issue._count} pages have hreflang tags placed outside the <head> section.`;
            break;
          case 'x-default URL not in cluster':
            issue.description = `${issue._count} x-default tags point to URLs not in the cluster.`;
            break;
          case 'x-default URL redirects':
            issue.description = `${issue._count} x-default tags point to redirecting URLs.`;
            break;
          case 'Possible geo-redirect':
            issue.description = `${issue._count} hreflang URLs redirect to your current location. This is likely geo-based redirecting — search engine crawlers are typically not affected.`;
            break;
          default:
            issue.description = `${issue._count} instances of this issue found across the cluster.`;
        }
      }
      result.push(issue);
    }

    // Smart fix prioritisation: calculate impact and sort
    const SEVERITY_WEIGHT = { critical: 12, warning: 5, info: 1 };
    for (const issue of result) {
      issue.impact = (SEVERITY_WEIGHT[issue.severity] || 1) * issue._count;
    }
    result.sort((a, b) => {
      const sevOrder = { critical: 0, warning: 1, info: 2 };
      if (sevOrder[a.severity] !== sevOrder[b.severity]) return sevOrder[a.severity] - sevOrder[b.severity];
      return b.impact - a.impact;
    });
    if (result.length > 0) {
      let maxImpact = 0, maxIdx = 0;
      result.forEach((issue, i) => { if (issue.impact > maxImpact) { maxImpact = issue.impact; maxIdx = i; } });
      result[maxIdx]._fixFirst = true;
    }

    return result;
  }

  // ===== RENDER DETECTION SOURCES =====
  function renderDetectionSources(sources, sitemapData) {
    const container = $('detection-sources');
    container.style.display = 'flex';

    const htmlTag = $('src-html');
    const headerTag = $('src-header');
    const sitemapTag = $('src-sitemap');

    htmlTag.className = 'source-tag' + (sources.html ? ' active' : '');
    headerTag.className = 'source-tag' + (sources.header ? ' active' : '');
    sitemapTag.className = 'source-tag' + (sources.sitemap ? ' active' : '');

    // Show conflict state if sitemap has different data
    if (sources.html && sources.sitemap) {
      // Check for conflicts — if any issue is a sitemap/html conflict, mark it
      if (_exportData && _exportData.issues.some(i => i.title === 'Sitemap/HTML conflict')) {
        sitemapTag.classList.add('conflict');
      }
    }
  }

  // ===== RENDER CLUSTER MATRIX =====
  function renderClusterMatrix(clusterData, sourceTags) {
    const matrixSection = $('matrix-section');
    const table = $('cluster-matrix');

    // Need at least 2 pages for a matrix
    if (clusterData.size < 2) {
      matrixSection.style.display = 'none';
      return;
    }

    matrixSection.style.display = '';
    table.innerHTML = '';

    // Build ordered list of pages
    const pages = [...clusterData.entries()].map(([normUrl, data]) => ({
      normUrl,
      url: data.url,
      label: data.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === normUrl)?.hreflang || shortenUrl(data.url),
      data
    }));

    // Header row
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = '<th class="row-header">Page \\ Target</th>';
    for (const page of pages) {
      const th = document.createElement('th');
      th.title = page.url;
      th.innerHTML = `${getFlagImg(page.label)} ${escHtml(page.label)}`;
      headerRow.appendChild(th);
    }
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Data rows
    const tbody = document.createElement('tbody');
    for (const rowPage of pages) {
      const tr = document.createElement('tr');

      // Row label
      const labelTd = document.createElement('td');
      labelTd.className = 'row-label';
      labelTd.title = rowPage.url;
      labelTd.innerHTML = `${getFlagImg(rowPage.label)} ${escHtml(rowPage.label)}`;
      tr.appendChild(labelTd);

      for (const colPage of pages) {
        const td = document.createElement('td');

        if (!rowPage.data.fetchOk) {
          // Page couldn't be fetched
          td.innerHTML = '<div class="matrix-cell na" title="Page unreachable"></div>';
        } else if (rowPage.normUrl === colPage.normUrl) {
          // Self-reference check
          const hasSelf = rowPage.data.tags.some(t => normalizeUrl(t.href) === rowPage.normUrl);
          td.innerHTML = `<div class="matrix-cell ${hasSelf ? 'self' : 'miss'}" title="${hasSelf ? 'Self-referencing ✓' : 'Missing self-ref ✗'}"></div>`;
        } else {
          // Does this row's page link to the column's page?
          const hasLink = rowPage.data.tags.some(t => normalizeUrl(t.href) === colPage.normUrl);
          td.innerHTML = `<div class="matrix-cell ${hasLink ? 'ok' : 'miss'}" title="${hasLink ? 'Confirmed ✓' : 'Missing ✗'}"></div>`;
        }

        tr.appendChild(td);
      }

      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
  }

  // ===== RENDER PAGE DETAILS =====
  function renderPageDetails(clusterData, sourceTags, issues) {
    const pageDetails = $('page-details');
    pageDetails.innerHTML = '';

    for (const [url, data] of clusterData) {
      const pageIssues = issues.filter(i => i.pages.some(p => normalizeUrl(p) === url));
      const hasIssues = pageIssues.length > 0;
      const hreflangLabel = data.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === url)?.hreflang || '?';

      // Page row
      const row = document.createElement('div');
      row.className = 'page-row';

      const canonicalMatch = data.canonical ? normalizeUrl(data.canonical) === url : null;
      const canonicalLine = data.canonical
        ? `<span class="page-canonical" title="${escHtml(data.canonical)}"><span class="canonical-label">canonical:</span> ${escHtml(shortenUrl(data.canonical))} <span class="canonical-status ${canonicalMatch ? 'canon-ok' : 'canon-err'}">${canonicalMatch ? '\u2713' : '\u2717'}</span></span>`
        : '';

      row.innerHTML = `
        <span class="page-toggle">\u25B8</span>
        <span class="page-hreflang-tag">${getFlagImg(hreflangLabel)} ${escHtml(hreflangLabel)}</span>
        <div class="page-url-group">
          <span class="page-url" title="${escHtml(data.url)}">${escHtml(shortenUrl(data.url))}</span>
          ${canonicalLine}
        </div>
        <span class="page-tag-count">${data.tags.length} tags</span>
        <span class="page-status-icon ${data.fetchOk ? (hasIssues ? 'page-status-warn' : 'page-status-ok') : 'page-status-error'}">
          ${data.fetchOk ? (hasIssues ? warnSvg() : checkSvg()) : errorSvg()}
        </span>
      `;

      // Expanded content
      const expanded = document.createElement('div');
      expanded.className = 'page-expanded-content';

      // Meta badges
      const metaBadges = document.createElement('div');
      metaBadges.className = 'page-meta-badges';
      let hasBadges = false;

      // Build meta badges HTML as single string to avoid repeated innerHTML +=
      let badgeHtml = '';
      if (data.redirected) {
        badgeHtml += `<span class="meta-badge redirect" title="Redirects to ${escHtml(data.finalUrl)}">Redirected</span>`;
        hasBadges = true;
      }
      if (data.isNoindex) {
        badgeHtml += `<span class="meta-badge noindex">Noindex</span>`;
        hasBadges = true;
      }
      if (data.htmlLang) {
        const assignedHreflang = hreflangLabel;
        const htmlBase = data.htmlLang.split('-')[0].toLowerCase();
        const hreflangBase = assignedHreflang.split('-')[0].toLowerCase();
        const matches = htmlBase === hreflangBase || assignedHreflang === 'x-default' || assignedHreflang === '?';
        badgeHtml += `<span class="meta-badge ${matches ? 'lang-match' : 'lang-mismatch'}" title="<html lang='${escHtml(data.htmlLang)}'>">lang="${escHtml(data.htmlLang)}"${matches ? ' ✓' : ' ✗'}</span>`;
        hasBadges = true;
      }
      if (data.contentLanguage) {
        const assignedHreflang = hreflangLabel;
        const clBase = data.contentLanguage.split('-')[0].split(',')[0].trim().toLowerCase();
        const hreflangBase = assignedHreflang.split('-')[0].toLowerCase();
        const matches = clBase === hreflangBase || assignedHreflang === 'x-default' || assignedHreflang === '?';
        badgeHtml += `<span class="meta-badge ${matches ? 'lang-match' : 'lang-mismatch'}" title="Content-Language: ${escHtml(data.contentLanguage)}">CL: ${escHtml(data.contentLanguage)}${matches ? ' \u2713' : ' \u2717'}</span>`;
        hasBadges = true;
      }
      if (data.responseTime != null) {
        const ms = data.responseTime;
        let rtClass = 'rt-fast', rtLabel = `${ms}ms`;
        if (ms >= 2000) { rtClass = 'rt-slow'; rtLabel = `${(ms / 1000).toFixed(1)}s`; }
        else if (ms >= 500) { rtClass = 'rt-medium'; }
        badgeHtml += `<span class="meta-badge ${rtClass}" title="Response time: ${ms}ms">${rtLabel}</span>`;
        hasBadges = true;
      }
      if (hasBadges) metaBadges.innerHTML = badgeHtml;

      if (hasBadges) {
        expanded.appendChild(metaBadges);
      }

      if (!data.fetchOk) {
        expanded.insertAdjacentHTML('beforeend', `<div style="font-size:0.72rem;color:var(--orange-earth);padding:4px 0;">Unable to fetch: ${escHtml(data.error || 'Unknown error')}</div>`);
      } else if (data.tags.length === 0) {
        expanded.insertAdjacentHTML('beforeend', `<div style="font-size:0.72rem;color:var(--mid-grey);padding:4px 0;">No hreflang tags found on this page.</div>`);
      } else {
        for (const tag of data.tags) {
          const detailRow = document.createElement('div');
          detailRow.className = 'page-detail-row';
          const isSelf = normalizeUrl(tag.href) === url;
          const sourceLabel = tag.source && tag.source !== 'html' ? ` [${tag.source}]` : '';
          detailRow.innerHTML = `
            <span class="page-detail-hreflang">${getFlagImg(tag.hreflang)} ${escHtml(tag.hreflang)}</span>
            <span class="page-detail-url" title="${escHtml(tag.href)}">${escHtml(shortenUrl(tag.href))}${isSelf ? ' (self)' : ''}${sourceLabel}</span>
            <span class="page-detail-status ok">\u2713</span>
          `;
          expanded.appendChild(detailRow);
        }
      }

      // Add canonical info
      if (data.canonical) {
        const canonRow = document.createElement('div');
        canonRow.className = 'page-detail-row';
        canonRow.innerHTML = `
          <span class="page-detail-hreflang" style="color:var(--blue-glass);">canonical</span>
          <span class="page-detail-url" title="${escHtml(data.canonical)}">${escHtml(shortenUrl(data.canonical))}</span>
          <span class="page-detail-status ${normalizeUrl(data.canonical) === url ? 'ok' : 'err'}">${normalizeUrl(data.canonical) === url ? '\u2713' : '\u2717'}</span>
        `;
        expanded.appendChild(canonRow);
      }

      // Copy fix code button (if this page has issues)
      if (hasIssues && data.fetchOk) {
        const fixCode = generateFixCode(url, data, sourceTags, clusterData);
        if (fixCode) {
          const copyBtn = document.createElement('button');
          copyBtn.className = 'btn-copy-fix';
          copyBtn.innerHTML = `
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <rect x="3.5" y="3.5" width="7" height="7" rx="1" stroke="currentColor" stroke-width="1.2"/>
              <path d="M8.5 3.5V2a1 1 0 00-1-1H2a1 1 0 00-1 1v5.5a1 1 0 001 1h1.5" stroke="currentColor" stroke-width="1.2"/>
            </svg>
            <span>Copy fix code for this page</span>
          `;
          copyBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(fixCode).then(() => {
              copyBtn.classList.add('copied');
              copyBtn.querySelector('span').textContent = 'Copied to clipboard!';
              setTimeout(() => {
                copyBtn.classList.remove('copied');
                copyBtn.querySelector('span').textContent = 'Copy fix code for this page';
              }, 2000);
            }).catch(() => {});
          });
          expanded.appendChild(copyBtn);
        }
      }

      row.addEventListener('click', () => {
        const isExpanded = row.classList.contains('expanded');
        pageDetails.querySelectorAll('.page-row.expanded').forEach(r => r.classList.remove('expanded'));
        pageDetails.querySelectorAll('.page-expanded-content.visible').forEach(e => e.classList.remove('visible'));
        if (!isExpanded) {
          row.classList.add('expanded');
          expanded.classList.add('visible');
        }
      });

      pageDetails.appendChild(row);
      pageDetails.appendChild(expanded);
    }
  }

  // ===== GENERATE FIX CODE FOR A PAGE =====
  function generateFixCode(normUrl, pageData, sourceTags, clusterData) {
    const lines = [];
    lines.push(`<!-- Hreflang fix for ${pageData.url} -->`);

    // Generate the complete set of tags this page should have

    // Check what's missing
    for (const tag of sourceTags) {
      const tagNorm = normalizeUrl(tag.href);
      const hasTag = pageData.tags.some(t =>
        t.hreflang === tag.hreflang && normalizeUrl(t.href) === tagNorm
      );
      if (!hasTag) {
        lines.push(`<link rel="alternate" hreflang="${tag.hreflang}" href="${tag.href}" />`);
      }
    }

    // Check self-referencing
    const hasSelf = pageData.tags.some(t => normalizeUrl(t.href) === normUrl);
    if (!hasSelf) {
      const selfLang = pageData.hreflangOnSource || '??';
      if (!lines.some(l => l.includes(`href="${pageData.url}"`))) {
        lines.push(`<link rel="alternate" hreflang="${selfLang}" href="${pageData.url}" />`);
      }
    }

    if (lines.length <= 1) return null; // Only the comment, no actual fixes
    return lines.join('\n');
  }


  // ===== UI HELPERS =====
  function createIssueCard(issue) {
    const card = document.createElement('div');
    card.className = 'issue-card';

    let pagesHtml = '';
    // Show affected hreflang codes as chips when available, otherwise show page URLs
    if (issue._codes && issue._codes.length > 0) {
      pagesHtml = `<div class="issue-pages">${
        issue._codes.map(c => `<span class="issue-page-tag" title="${escHtml(c)}">${escHtml(c)}</span>`).join('')
      }</div>`;
    } else if (issue.pages.length > 0) {
      pagesHtml = `<div class="issue-pages">${
        issue.pages.map(p => `<span class="issue-page-tag" title="${escHtml(p)}">${escHtml(shortenUrl(p))}</span>`).join('')
      }</div>`;
    }

    const impactBadge = issue.impact ? `<span class="issue-impact-badge">+${Math.min(issue.impact, 100)} pts</span>` : '';
    const fixFirstLabel = issue._fixFirst ? `<span class="issue-fix-first">FIX THIS FIRST</span>` : '';

    card.innerHTML = `
      <div class="issue-card-header">
        <span class="issue-severity-dot ${issue.severity}"></span>
        <span class="issue-severity-label ${issue.severity}">${issue.severity}</span>
        ${impactBadge}
        ${fixFirstLabel}
      </div>
      <div class="issue-card-body">
        <div class="issue-title">${escHtml(issue.title)}</div>
        <div class="issue-description">${escHtml(issue.description)}</div>
        ${pagesHtml}
        <div class="issue-fix">
          <span class="issue-fix-icon">${fixSvg()}</span>
          <span class="issue-fix-text">${escHtml(issue.fix)}</span>
        </div>
      </div>
    `;

    return card;
  }

  function animateNumber(el, target, duration) {
    const start = performance.now();
    function update(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(eased * target);
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  function escHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function checkSvg() {
    return '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M4.5 7l2 2 3-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }

  function warnSvg() {
    return '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><line x1="7" y1="4" x2="7" y2="7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="7" cy="10" r="0.8" fill="currentColor"/></svg>';
  }

  function errorSvg() {
    return '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M5 5l4 4M9 5l-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';
  }

  function fixSvg() {
    return '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M4.5 1.5v3h-3" stroke="#F2BC63" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.5 4.5a4.5 4.5 0 018.12-1.8" stroke="#F2BC63" stroke-width="1.2" stroke-linecap="round"/><path d="M7.5 10.5v-3h3" stroke="#F2BC63" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.5 7.5a4.5 4.5 0 01-8.12 1.8" stroke="#F2BC63" stroke-width="1.2" stroke-linecap="round"/></svg>';
  }

  // ===== EXPORT: Matrix Visual (PNG) =====
  async function exportMatrixVisual() {
    if (!_exportData) return;
    const { clusterData, sourceTags, pageUrl } = _exportData;
    if (clusterData.size < 2) return;

    const pages = [...clusterData.entries()].map(([normUrl, data]) => ({
      normUrl,
      url: data.url,
      label: data.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === normUrl)?.hreflang || shortenUrl(data.url),
      data
    }));

    // Preload flag images (Twemoji SVGs for cross-platform support)
    const flagSize = 14;
    const flagPad = 4;
    const flagMap = new Map();
    await Promise.all(pages.map(p => {
      const url = getFlagUrl(p.label);
      if (!url || flagMap.has(url)) return Promise.resolve();
      return new Promise(resolve => {
        const img = new Image();
        img.onload = () => { flagMap.set(url, img); resolve(); };
        img.onerror = () => { resolve(); }; // skip if fails
        img.src = url;
      });
    }));

    // Measure label widths (flag image + text)
    const measure = document.createElement('canvas').getContext('2d');
    measure.font = '600 11px Poppins, sans-serif';
    const textLabels = pages.map(p => p.label);
    const maxLabelW = Math.max(...textLabels.map(l => measure.measureText(l).width)) + flagSize + flagPad + 20;

    // Layout constants
    const cell = 28;
    const pad = 24;
    const headerH = 56;
    const titleH = 50;
    const colHeaderH = 48;
    const legendH = 44;
    const footerH = 32;
    const n = pages.length;
    const gridW = n * cell;
    const gridH = n * cell;
    const W = Math.max(480, pad + maxLabelW + gridW + pad);
    const H = headerH + titleH + colHeaderH + gridH + legendH + footerH;

    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#25242B';
    ctx.fillRect(0, 0, W, H);

    // Subtle grid texture
    ctx.strokeStyle = 'rgba(249,245,241,0.03)';
    ctx.lineWidth = 1;
    for (let y = 0; y < H; y += 30) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    for (let x = 0; x < W; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }

    // Header bar
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    ctx.fillRect(0, 0, W, headerH);
    ctx.font = '800 16px Poppins, sans-serif';
    ctx.fillStyle = '#F9F5F1';
    ctx.fillText('HREFLANG ', pad, 35);
    const hwText = ctx.measureText('HREFLANG ');
    ctx.fillStyle = '#F2BC63';
    ctx.fillText('PRO', pad + hwText.width, 35);
    ctx.font = '400 11px Poppins, sans-serif';
    ctx.fillStyle = 'rgba(249,245,241,0.4)';
    const dateStr = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const dateW = ctx.measureText(dateStr).width;
    ctx.fillText(dateStr, W - pad - dateW, 35);

    // Title + URL
    ctx.font = '600 9px Poppins, sans-serif';
    ctx.fillStyle = 'rgba(249,245,241,0.35)';
    ctx.letterSpacing = '1.5px';
    ctx.fillText('CLUSTER MATRIX', pad, headerH + 20);
    ctx.letterSpacing = '0px';
    ctx.font = '400 10px Poppins, sans-serif';
    ctx.fillStyle = 'rgba(249,245,241,0.45)';
    const truncUrl = pageUrl.length > 90 ? pageUrl.slice(0, 87) + '...' : pageUrl;
    ctx.fillText(truncUrl, pad, headerH + 38);

    // Grid origin
    const gx = pad + maxLabelW;
    const gy = headerH + titleH + colHeaderH;

    // Helper to draw flag + label
    const drawFlagLabel = (x, y, page, font, color) => {
      const flagUrl = getFlagUrl(page.label);
      const flagImg = flagUrl ? flagMap.get(flagUrl) : null;
      let textX = x;
      if (flagImg) {
        ctx.drawImage(flagImg, x, y - flagSize / 2, flagSize, flagSize);
        textX += flagSize + flagPad;
      }
      ctx.font = font;
      ctx.fillStyle = color;
      ctx.fillText(page.label, textX, y + 4);
    };

    // Column headers (rotated)
    const colFont = '600 9px Poppins, sans-serif';
    for (let c = 0; c < n; c++) {
      const cx = gx + c * cell + cell / 2;
      const cy = gy - 6;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-Math.PI / 3);
      drawFlagLabel(0, 0, pages[c], colFont, 'rgba(249,245,241,0.7)');
      ctx.restore();
    }

    // Row labels + grid cells
    for (let r = 0; r < n; r++) {
      const rowPage = pages[r];
      const ry = gy + r * cell;

      // Alternating row background
      if (r % 2 === 0) {
        ctx.fillStyle = 'rgba(255,255,255,0.02)';
        ctx.fillRect(pad, ry, W - pad * 2, cell);
      }

      // Row label with flag
      drawFlagLabel(pad + 4, ry + cell / 2, rowPage, '600 10px Poppins, sans-serif', 'rgba(249,245,241,0.75)');

      // Cells
      for (let c = 0; c < n; c++) {
        const colPage = pages[c];
        const dotX = gx + c * cell + cell / 2;
        const dotY = ry + cell / 2;
        const dotR = 7;

        let color;
        if (!rowPage.data.fetchOk) {
          color = 'rgba(249,245,241,0.12)';
        } else if (rowPage.normUrl === colPage.normUrl) {
          const hasSelf = rowPage.data.tags.some(t => normalizeUrl(t.href) === rowPage.normUrl);
          color = hasSelf ? '#F2BC63' : '#E53935';
        } else {
          const hasLink = rowPage.data.tags.some(t => normalizeUrl(t.href) === colPage.normUrl);
          color = hasLink ? '#43A047' : '#E53935';
        }

        ctx.beginPath();
        ctx.arc(dotX, dotY, dotR, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
      }
    }

    // Grid lines
    ctx.strokeStyle = 'rgba(249,245,241,0.06)';
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= n; r++) {
      ctx.beginPath(); ctx.moveTo(gx, gy + r * cell); ctx.lineTo(gx + gridW, gy + r * cell); ctx.stroke();
    }
    for (let c = 0; c <= n; c++) {
      ctx.beginPath(); ctx.moveTo(gx + c * cell, gy); ctx.lineTo(gx + c * cell, gy + gridH); ctx.stroke();
    }

    // Legend
    const ly = gy + gridH + 16;
    const legendItems = [
      { color: '#43A047', label: 'Confirmed' },
      { color: '#E53935', label: 'Missing' },
      { color: '#F2BC63', label: 'Self-ref' }
    ];
    ctx.font = '500 10px Poppins, sans-serif';
    let llx = pad;
    for (const item of legendItems) {
      ctx.beginPath(); ctx.arc(llx + 6, ly, 5, 0, Math.PI * 2);
      ctx.fillStyle = item.color; ctx.fill();
      ctx.fillStyle = 'rgba(249,245,241,0.5)';
      ctx.fillText(item.label, llx + 16, ly + 4);
      llx += ctx.measureText(item.label).width + 36;
    }

    // Footer
    ctx.font = '400 9px Poppins, sans-serif';
    ctx.fillStyle = 'rgba(249,245,241,0.2)';
    const footer = 'Generated by Hreflang Pro';
    const footW = ctx.measureText(footer).width;
    ctx.fillText(footer, W / 2 - footW / 2, H - 12);

    // Download
    canvas.toBlob(blob => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const host = (() => { try { return new URL(pageUrl).hostname; } catch { return 'matrix'; } })();
      a.download = `hreflang-matrix-${host}-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
      flashButton($('btn-export-matrix'));
    }, 'image/png');
  }

  // ===== EXPORT: CSV (Actionable Fix List) =====
  function exportCSV() {
    if (!_exportData) return;
    const { score, issues, clusterData, sourceTags, pageUrl } = _exportData;
    const rows = [];
    let actionNum = 0;

    // Summary header
    rows.push(['HREFLANG AUDIT REPORT'].join(','));
    rows.push([`Audited URL:,${csvEscape(pageUrl)}`]);
    rows.push([`Date:,${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}`]);
    rows.push([`Health Score:,${score}/100`]);
    rows.push([`Pages in Cluster:,${clusterData.size}`]);
    rows.push([`Critical Issues:,${issues.filter(i => i.severity === 'critical').length}`]);
    rows.push([`Warnings:,${issues.filter(i => i.severity === 'warning').length}`]);
    rows.push('');
    rows.push('');

    // Action items
    rows.push(['ACTION ITEMS — Fix these in order of priority'].join(','));
    rows.push([
      '#',
      'Priority',
      'Page to Fix',
      'Issue',
      'What\'s Wrong',
      'Code to Add or Change',
      'Related Page'
    ].join(','));

    for (const issue of issues) {
      if (issue.title === 'Missing self-referencing tag') {
        for (const pg of issue.pages) {
          const normUrl = normalizeUrl(pg);
          const entry = clusterData.get(normUrl);
          const lang = entry?.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === normUrl)?.hreflang || 'UNKNOWN';
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Missing self-referencing tag',
            `This page has hreflang tags but doesn't include itself.`,
            csvEscape(`<link rel="alternate" hreflang="${lang}" href="${pg}" />`),
            ''
          ].join(','));
        }
      }
      else if (issue.title === 'Missing return tag') {
        if (issue.pages.length >= 2) {
          const sourcePage = issue.pages[0];
          const targetPage = issue.pages[1];
          const sourceNorm = normalizeUrl(sourcePage);
          const sourceEntry = clusterData.get(sourceNorm);
          const sourceLang = sourceEntry?.hreflangOnSource || sourceTags.find(t => normalizeUrl(t.href) === sourceNorm)?.hreflang || 'UNKNOWN';
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(targetPage),
            'Missing return tag',
            csvEscape(`${shortenUrl(sourcePage)} references this page but this page doesn't link back.`),
            csvEscape(`<link rel="alternate" hreflang="${sourceLang}" href="${sourcePage}" />`),
            csvEscape(sourcePage)
          ].join(','));
        }
      }
      else if (issue.title === 'Unreachable page') {
        for (const pg of issue.pages) {
          const entry = clusterData.get(normalizeUrl(pg));
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Page unreachable',
            csvEscape(`Returned ${entry?.error || 'an error'}.`),
            csvEscape(`Fix the URL so it returns HTTP 200 — or remove its hreflang tag from every other page.`),
            ''
          ].join(','));
        }
      }
      else if (issue.title === 'Canonical mismatch') {
        for (const pg of issue.pages) {
          const entry = clusterData.get(normalizeUrl(pg));
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Canonical mismatch',
            csvEscape(`Canonical points to ${entry?.canonical || 'a different URL'}.`),
            csvEscape(`Change canonical to: <link rel="canonical" href="${pg}" /> — or move hreflang tags to canonicalised URL.`),
            csvEscape(entry?.canonical || '')
          ].join(','));
        }
      }
      else if (issue.title === 'Duplicate hreflang value') {
        for (const pg of issue.pages) {
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Duplicate hreflang value', csvEscape(issue.description),
            'Remove the duplicate hreflang tag. Each language code should appear only once per page.', ''
          ].join(','));
        }
      }
      else if (issue.title === 'Invalid hreflang code' || issue.title === 'Likely hreflang typo') {
        for (const pg of issue.pages) {
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            csvEscape(issue.title), csvEscape(issue.description),
            csvEscape(issue.fix), ''
          ].join(','));
        }
      }
      else if (issue.title === 'Missing hreflang tags') {
        for (const pg of issue.pages) {
          actionNum++;
          const allTags = sourceTags.map(t =>
            `<link rel="alternate" hreflang="${t.hreflang}" href="${t.href}" />`
          ).join('  ');
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'No hreflang tags on page',
            'This page is in the cluster but has zero hreflang tags.',
            csvEscape(`Add all ${sourceTags.length} hreflang tags. Full set: ${allTags}`), ''
          ].join(','));
        }
      }
      else if (issue.title === 'Hreflang URL redirects') {
        actionNum++;
        rows.push([
          actionNum, issue.severity.toUpperCase(),
          csvEscape(issue.pages[0] || 'All pages'),
          'Hreflang URL redirects',
          csvEscape(issue.description),
          csvEscape(issue.fix),
          csvEscape(issue._redirectTo || '')
        ].join(','));
      }
      else if (issue.title === 'Possible geo-redirect') {
        for (const pg of issue.pages) {
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Possible geo-redirect',
            csvEscape(issue.description),
            csvEscape(issue.fix),
            csvEscape(issue._redirectTo || '')
          ].join(','));
        }
      }
      else if (issue.title === 'HTML lang mismatch') {
        actionNum++;
        rows.push([
          actionNum, issue.severity.toUpperCase(),
          csvEscape(issue.pages[0] || ''),
          'HTML lang mismatch',
          csvEscape(issue.description),
          csvEscape(issue.fix), ''
        ].join(','));
      }
      else if (issue.title === 'Noindex with hreflang') {
        for (const pg of issue.pages) {
          actionNum++;
          rows.push([
            actionNum, issue.severity.toUpperCase(), csvEscape(pg),
            'Noindex with hreflang', csvEscape(issue.description),
            csvEscape(issue.fix), ''
          ].join(','));
        }
      }
      else if (issue.title === 'Relative URLs detected') {
        actionNum++;
        rows.push([
          actionNum, issue.severity.toUpperCase(),
          csvEscape(issue.pages[0] || 'Source page'),
          'Relative URLs in hreflang', csvEscape(issue.description),
          csvEscape(issue.fix), ''
        ].join(','));
      }
      else if (issue.title === 'Sitemap/HTML conflict') {
        actionNum++;
        rows.push([
          actionNum, issue.severity.toUpperCase(),
          csvEscape(issue.pages[0] || ''),
          'Sitemap/HTML conflict', csvEscape(issue.description),
          csvEscape(issue.fix), ''
        ].join(','));
      }
      else {
        // Generic fallback
        actionNum++;
        rows.push([
          actionNum, issue.severity.toUpperCase(),
          issue.pages.length > 0 ? csvEscape(issue.pages[0]) : 'All pages',
          csvEscape(issue.title), csvEscape(issue.description),
          csvEscape(issue.fix),
          issue.pages.length > 1 ? csvEscape(issue.pages.slice(1).join(' | ')) : ''
        ].join(','));
      }
    }

    if (actionNum === 0) {
      rows.push([1, 'PASS', '', 'No issues found', 'All hreflang checks passed. Your cluster is healthy.', 'No action required.', ''].join(','));
    }

    const csv = rows.join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const host = (() => { try { return new URL(pageUrl).hostname; } catch { return 'audit'; } })();
    a.download = `hreflang-fixes-${host}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    flashButton($('btn-export-csv'));
  }

  function csvEscape(str) {
    if (!str) return '';
    str = String(str);
    // Prevent CSV formula injection — prefix dangerous leading chars
    if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return str;
  }

  function flashButton(btn) {
    const origHtml = btn.innerHTML;
    btn.classList.add('success');
    btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 7l3 3 5-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Downloaded</span>`;
    setTimeout(() => {
      btn.classList.remove('success');
      btn.innerHTML = origHtml;
    }, 1800);
  }

  // ===== POP-OUT SERIALIZATION =====
  function serializeExportData(data) {
    return {
      score: data.score,
      issues: data.issues,
      clusterData: Array.from(data.clusterData.entries()),
      sourceTags: data.sourceTags,
      pageUrl: data.pageUrl,
      sources: data.sources,
      sitemapData: data.sitemapData
    };
  }

  function deserializeExportData(raw) {
    return {
      score: raw.score,
      issues: raw.issues,
      clusterData: new Map(raw.clusterData),
      sourceTags: raw.sourceTags,
      pageUrl: raw.pageUrl,
      sources: raw.sources,
      sitemapData: raw.sitemapData
    };
  }

  // ===== LOAD FROM STORAGE (Tab Mode) =====
  async function loadFromStorage() {
    try {
      showState('loading');
      $('loading-detail').textContent = 'Loading saved results...';

      const result = await chrome.storage.local.get(POPOUT_STORAGE_KEY);
      const raw = result[POPOUT_STORAGE_KEY];

      if (!raw) {
        showState('error');
        $('error-body').textContent = 'No scan data found. Please run a scan from the extension popup first.';
        return;
      }

      _exportData = deserializeExportData(raw);

      const { score, issues, clusterData, sourceTags, pageUrl, sources, sitemapData } = _exportData;

      // Render results exactly as a normal scan would
      renderResults(score, issues, clusterData, sourceTags, sources, sitemapData);

    } catch (err) {
      console.error('Failed to load from storage:', err);
      showState('error');
      $('error-body').textContent = 'Failed to load scan data: ' + (err.message || 'Unknown error');
    }
  }

  // ===== DARK MODE =====
  async function loadDarkMode() {
    try {
      const result = await chrome.storage.local.get('darkMode');
      if (result.darkMode) {
        document.body.classList.add('dark-mode');
      }
    } catch {}
  }

  $('btn-darkmode').addEventListener('click', () => toggleDarkMode());

  function toggleDarkMode() {
    const isDark = document.body.classList.toggle('dark-mode');
    chrome.storage.local.set({ darkMode: isDark }).catch(() => {});
  }

  // ===== KEYBOARD SHORTCUTS =====
  document.addEventListener('keydown', (e) => {
    // Don't fire shortcuts when typing in inputs
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
    // Don't fire with modifier keys (Ctrl, Alt, Meta)
    if (e.ctrlKey || e.altKey || e.metaKey) return;

    switch (e.key.toUpperCase()) {
      case 'R':
        if (!IS_TAB_MODE && STATES.results.style.display !== 'none') {
          e.preventDefault();
          showState('loading');
          $('loading-detail').textContent = 'Extracting hreflang tags from this page';
          runScan();
        }
        break;
      case 'C':
        if (_exportData) { e.preventDefault(); exportCSV(); }
        break;
      case 'X':
        if (_exportData && _exportData.clusterData.size >= 2) { e.preventDefault(); exportMatrixVisual(); }
        break;
      case 'D':
        e.preventDefault();
        toggleDarkMode();
        break;
    }
  });

  // ===== KICK OFF =====
  await loadDarkMode();

  if (IS_TAB_MODE) {
    loadFromStorage();
  } else {
    runScan();
  }
})();
